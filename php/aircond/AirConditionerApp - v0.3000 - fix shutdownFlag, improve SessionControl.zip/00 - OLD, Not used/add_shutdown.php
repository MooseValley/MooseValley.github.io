
ALTER TABLE `aircond`
ADD COLUMN shutdown BIT NULL;
