Win32HLP support for Windows 10, etc:

This software is provided by Komeil Bahmanpour
http://www.komeil.com/.  See below.

I modified the "Install.cmd" script to bypass incorrect Windows
version errors, so this now works on Windows 10, etc.

Installation instructions:
* Unzip the contents of the ZIP file to a temporary directory.
  e.g. c:\temp\
* Right click on "Install.cmd" and select "Run as Administrator".
  A command window will open and WinHLP will be installed, and you will
  see a bunch of messages ending with:  "The operation completed successfully."

Your Win32HLP files will now work on Windows 10, etc.  :)

Special thanks to Komeil for preparing this installer.  :)

Special ANTI-THANKS to Microsoft for not supporting their own products,
and leaving it to 3rd party developers to fix the gaps / issues.  :/

Moose
http://moosesoftware.16mb.com
____________________________________________________



********************************

http://www.komeil.com/download/1230

Komeil Bahmanpour
Download Center
---
winhlp32-windows-7-x86-x64-komeil.cab

Related article:
winhlp32-windows-7-x86-x64-komeil.cab
Windows Help program (WinHlp32.exe) for Windows 7 x86 & Windows 7 x64, includes winhlp32.exe, winhlp32.exe.mui, and Install.cmd, the Windows 7 WinHlp32 installer by Komeil Bahmanpour

Download
Information
File type: CAB Archive
Size: 151.41 kB
Revision: 23
Date published: 6/14/2009 2:07 AM UTC
Date modified: 6/27/2016 2:55 AM UTC
Tweets by @komeil
Contact Us | Privacy Policy | Terms of Use
Copyright � 1999-2017 Komeil Bahmanpour. All rights reserved.
Stats
